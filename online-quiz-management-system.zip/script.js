const qs=[
{q:"Which data structure follows FIFO (First In, First Out)?",o:["Stack","Queue","Tree","Graph"],a:1},
{q:"Which pointer connects to the next node in a singly linked list?",o:["previous","next","front","rear"],a:1},
{q:"Which language is used for the core implementation of this capstone?",o:["Python","Java","C","HTML"],a:2},
{q:"Which operation adds an item to a queue?",o:["Push","Pop","Enqueue","Traverse"],a:2},
{q:"What does automatic evaluation do?",o:["Create questions","Compare answers and calculate score","Delete users","Draw diagrams"],a:1}
];
let i=0,ans=[],student={};
function openQuiz(){document.getElementById("modal").classList.remove("hidden");start()}
function closeQuiz(){document.getElementById("modal").classList.add("hidden")}
function start(){document.getElementById("app").innerHTML=`<p class="eyebrow">STUDENT MODULE</p><h2>Start Demo Quiz</h2><p>Enter your details to begin.</p><label>Student Name</label><input id="name" class="input" placeholder="Your name"><label>Student ID</label><input id="sid" class="input" placeholder="Your ID"><button onclick="begin()">Start Quiz →</button>`}
function begin(){let n=document.getElementById("name").value.trim(),s=document.getElementById("sid").value.trim();if(!n||!s)return alert("Please enter your name and student ID.");student={n,s};i=0;ans=[];show()}
function show(){let q=qs[i];document.getElementById("app").innerHTML=`<p class="eyebrow">QUESTION ${i+1} / ${qs.length}</p><div class="progress"><span style="width:${(i+1)/qs.length*100}%"></span></div><div class="qbox"><h3>${q.q}</h3>${q.o.map((x,j)=>`<label class="option"><input type="radio" name="a" value="${j}"> ${String.fromCharCode(65+j)}. ${x}</label>`).join("")}</div><button onclick="next()">${i===qs.length-1?"Submit Quiz":"Next →"}</button>`}
function next(){let x=document.querySelector('input[name="a"]:checked');if(!x)return alert("Select an answer.");ans[i]=+x.value;if(i<qs.length-1){i++;show()}else result()}
function result(){let score=qs.reduce((n,q,j)=>n+(ans[j]===q.a),0),pct=Math.round(score/qs.length*100);document.getElementById("app").innerHTML=`<div class="result"><p class="eyebrow">QUIZ COMPLETED</p><h2>Well done, ${esc(student.n)}!</h2><div class="score">${pct}%</div><div class="resultgrid"><div><b>${score}</b><br>Correct</div><div><b>${qs.length-score}</b><br>Wrong</div><div><b>${qs.length}</b><br>Total</div><div><b>${pct>=50?"PASSED":"TRY AGAIN"}</b><br>Status</div></div><p>Student ID: ${esc(student.s)}</p><button onclick="closeQuiz()">Close</button></div>`}
function esc(x){return x.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}